<template>
  <van-nav-bar :title="title" />
</template>

<script>
export default {
  name: "topbar",
  data() {
    return {};
  },
  props: ["title"]
};
</script>

<style scoped lang="less">
.van-nav-bar {
  position: relative;
  z-index: 1;
  display: -webkit-box;
  display: -webkit-flex;
  display: flex;
  -webkit-box-align: center;
  -webkit-align-items: center;
  align-items: center;
  height: 46px;
  line-height: 1.5;
  text-align: center;
  background-color: #0396ff;
  -webkit-user-select: none;
  user-select: none;
  .van-nav-bar__title {
    max-width: 60%;
    margin: 0 auto;
    color: #fff;
    font-weight: 500;
    font-size: 16px;
  }
}
</style>
