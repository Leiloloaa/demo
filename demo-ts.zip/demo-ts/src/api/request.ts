import axios, { AxiosRequestConfig } from 'axios'

export function request(config: AxiosRequestConfig) {

    //1.创建axios实例
    const instance = axios.create({
        baseURL: 'https://hostapi.mzapi.com',
        timeout: 30000
    })

    //2.axios的拦截
    //2.1请求拦截
    instance.interceptors.request.use(config => {
        if (localStorage.getItem('tenantId')) {
            config.headers['Abp.TenantId'] = localStorage.getItem('tenantId')
        }
        if (localStorage.getItem('token')) {
            config.headers['Authorization'] = 'Bearer' + localStorage.getItem('token')
        }
        return config
    }, err => {
        console.log(err)
    })

    //2.2响应拦截
    instance.interceptors.response.use(res => {
        return res.data
    }, err => {
        console.log(err)
    })

    //3.发送网络请求
    return instance(config)
}