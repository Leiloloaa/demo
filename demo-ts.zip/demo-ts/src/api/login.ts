import { request } from "./request";

// 获取当前租户配置
const IsTenantAvailable = (data: any) => {
    return request({
        url: "/api/services/app/Account/IsTenantAvailable",
        method: "post",
        data: data
    });
};

// 扩展登录
const GetExternalAuthenticationProviders = (params: number) => {
    return request({
        url: "/api/TokenAuth/GetExternalAuthenticationProviders",
        method: "get",
        params: params
    });
};

const wechatCode = (params: any) => {
    return request({
        url: "/api/TokenAuth/WechatLogin",
        method: "get",
        params: params
    });
};

const wechatLogin = (
    providerKey: any,
    providerAccessCode: any,
    returnUrl: any,
    authProvider: any
) => {
    return request({
        url: "/api/TokenAuth/ExternalAuthenticate",
        method: "post",
        data: {
            authProvider,
            providerKey,
            providerAccessCode,
            returnUrl,
            singleSignIn: true
        }
    });
};

export default {
    IsTenantAvailable,
    GetExternalAuthenticationProviders,
    wechatCode,
    wechatLogin
};
