import Vue from "vue";
import App from "./App.vue";
import "./registerServiceWorker";
import router from "./router";
import store from "./store";
import "../src/styles/_varuables.less";
import { Button } from "vant";
import { NavBar } from "vant";
import { Field } from "vant";
import { Empty } from "vant";
Vue.use(Button);
Vue.use(NavBar);
Vue.use(Field);
Vue.use(Empty);
Vue.config.productionTip = false;

new Vue({
    router,
    store,
    render: h => h(App)
}).$mount("#app");
