<template>
  <div>
    <topbar :title="title"></topbar>
    <van-empty
      description="设备已激活"
      image="//oss.szqan.com/app2/other/finish.png"
    >
      <van-button round type="danger" class="bottom-button" @click="close()">
        确认
      </van-button>
    </van-empty>
  </div>
</template>

<script>
import topbar from "components/topbar.vue";
import wx from "weixin-js-sdk";

export default {
  data() {
    return {
      title: "设备激活"
    };
  },
  components: {
    topbar
  },
  mounted() {
    if (/(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent)) {
      //ios
    } else if (/(Android)/i.test(navigator.userAgent)) {
      //android
    }
  },
  methods: {
    close() {
      wx.closeWindow();
    }
  }
};
</script>

<style>
.bottom-button {
  margin-top: 5vh;
  width: 160px;
  height: 40px;
}
</style>
