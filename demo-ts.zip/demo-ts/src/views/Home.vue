<template>
  <div class="home">
    <topbar :title="title"></topbar>
    <div class="content">
      <span class="title">请输入租户编码</span>
      <van-field
        v-model="tenant"
        clearable
        left-icon="friends-o"
        right-icon="warning-o"
        placeholder="租户编码"
        autofocus="true"
      />
      <van-button
        color="linear-gradient(to right, #ABDCFF, #0396FF)"
        class="myBtn"
        round
        @click="getLogin()"
      >
        确定
      </van-button>
    </div>
  </div>
</template>

<script>
import topbar from "components/topbar.vue";
import local from "@/utils/localStorage";
export default {
  data() {
    return {
      title: "租户登录",
      tenant: "",
      devsn: this.$route.query.devsn,
      devtype: this.$route.query.devtype
    };
  },
  created() {
    local.setItem("devsn", this.devsn);
    local.setItem("devtype", this.devtype);
  },
  components: {
    topbar
  },
  methods: {
    getLogin() {
      if (this.tenant == "") {
        return 1;
      } else {
        local.setItem("tenant", this.tenant);
        this.$router.push({ path: "/login" });
      }
    }
  }
};
</script>

<style lang="less" scoped>
.home {
  width: 100vw;
  height: 100vh;
  background-image: url("//oss.szqan.com/app2/other/bg.jpg");
  background-size: 100% 100%;
}

.content {
  margin: 20vh 8vh;

  .title {
    display: inline-block;
    margin-bottom: 5vh;
  }
}

.van-cell {
  position: relative;
  display: -webkit-box;
  display: -webkit-flex;
  display: flex;
  box-sizing: border-box;
  width: 100%;
  padding: 10px 16px;
  overflow: hidden;
  color: #323233;
  font-size: 14.5px;
  line-height: 33px;
  background-color: #fff;
  border-radius: 5px;
}
</style>
