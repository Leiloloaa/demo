<template>
  <div class="deviceInfo">
    <topbar :title="title"></topbar>
    <div class="content">
      <van-field v-model="sn" left-icon="debit-pay" readonly />
      <van-field
        v-model="devCode"
        clearable
        left-icon="coupon-o"
        right-icon="warning-o"
        placeholder="设备编号"
        autofocus="true"
      />
      <van-field
        v-model="wandian"
        clearable
        left-icon="location-o"
        right-icon="warning-o"
        placeholder="设备网点"
      />
      <van-button
        color="linear-gradient(to right, #ABDCFF, #0396FF)"
        class="myBtn"
        round
        @click="activeDev()"
      >
        提交
      </van-button>
    </div>
  </div>
</template>

<script>
import topbar from "components/topbar.vue";
import local from "@/utils/localStorage";

export default {
  data() {
    return {
      title: "设备登记",
      sn: local.getItem("devsn"),
      devCode: "",
      wandian: "",
      pointx: "",
      pointy: ""
    };
  },
  created() {
    // 组件的生命周期钩子函数
    // console.log(this.$route.query.id);
  },
  components: {
    topbar
  },
  methods: {
    activeDev() {
      this.$router.push({ path: "/finish" });
    }
  }
};
</script>

<style lang="less" scoped>
.van-cell {
  position: relative;
  display: -webkit-box;
  display: -webkit-flex;
  display: flex;
  box-sizing: border-box;
  width: 100%;
  padding: 10px 16px;
  overflow: hidden;
  color: #323233;
  font-size: 14.5px;
  line-height: 33px;
  background-color: #fff;
}

.deviceInfo {
  width: 100vw;
  height: 100vh;
  background-image: url("//oss.szqan.com/app2/other/bg.jpg");
  background-size: 100% 100%;
}

.content {
  margin: 20vh 8vh;
}

.van-cell {
  position: relative;
  display: -webkit-box;
  display: -webkit-flex;
  display: flex;
  box-sizing: border-box;
  width: 100%;
  padding: 10px 16px;
  overflow: hidden;
  color: #323233;
  font-size: 14.5px;
  line-height: 33px;
  background-color: #fff;
}
</style>
