<template>
  <div>
    <span class="login">正在登录中，请稍等...</span>
  </div>
</template>

<script>
import LoginServer from "@/api/login.ts";
import local from "@/utils/localStorage";

export default {
  data() {
    return {
      tenancyname: local.getItem("tenant"),
      code: "",
      returnUrl: window.location.href
    };
  },
  created() {
    this.getTanentId();
  },
  methods: {
    // 获取租户ID
    getTanentId() {
      LoginServer.IsTenantAvailable({ tenancyname: this.tenancyname }).then(
        res => {
          local.setItem("tenantId", res.result.tenantId);
          local.setItem("loginProviderName", res.result.loginProviderName);
          this.getExternalAuthenticationProviders(res.result.tenantId);
        },
        error => {
          console.log("错误", error.message);
        }
      );
    },
    getExternalAuthenticationProviders(tenantId) {
      LoginServer.GetExternalAuthenticationProviders(tenantId).then(res => {
        this.startLogin(res.result[0].name, res.result[0].clientId);
      });
    },
    // 微信登陆
    startLogin(authProvider, clientId) {
      this.getCode();
      if (!this.code) {
        LoginServer.wechatCode(this.returnUrl, clientId).then();
        window.location.href =
          "https://hostapi.mzapi.com/api/TokenAuth/WechatLogin?clientId=" +
          clientId +
          "&returnUrl=" +
          this.returnUrl;
      } else {
        this.wechatLogin(authProvider);
      }
    },
    getCode() {
      if (this.$route.query.code != null) {
        this.code = this.$route.query.code;
      }
    },
    wechatLogin(authProvider) {
      LoginServer.wechatLogin(
        this.code,
        this.code,
        this.returnUrl,
        authProvider
      ).then(res => {
        local.setItem("token", res.result.accessToken);
        this.$router.push({ path: "/Device" });
      });
    }
  }
};
</script>

<style lang="less" scoped>
.login {
  margin-top: 10px;
}
</style>
