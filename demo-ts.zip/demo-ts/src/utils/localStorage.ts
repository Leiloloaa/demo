function getItem(key: string) {
    const item = localStorage.getItem(key);
    if (item) {
        return item;
    }
    return "";
}

// 获取对象的是要转换
function getItemJson(key: string) {
    const item = localStorage.getItem(key);
    if (item) {
        return JSON.parse(item);
    }
    return null;
}

function setItem(key: string, value: string) {
    localStorage.setItem(key, value);
}

function removeItem(key: string) {
    localStorage.removeItem(key);
}

function clear() {
    localStorage.clear();
}

export default {
    getItem,
    getItemJson,
    setItem,
    removeItem,
    clear
};
