<template>
  <div class="home">
    <van-nav-bar title="设备激活" />
    <div class="content">
      <span class="title">请输入租户编码</span>
      <van-field
        v-model="tenant"
        clearable
        left-icon="friends-o"
        right-icon="warning-o"
        placeholder="租户编码"
        autofocus="true"
      />
      <van-button
        color="linear-gradient(to right, #ABDCFF, #0396FF)"
        class="myBtn"
        @click="getLogin()"
      >
        确定
      </van-button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tenant: "",
      devsn: this.$route.query.devsn,
      devtype: this.$route.query.devtype
    };
  },
  created(){
      localStorage.setItem("devsn", this.devsn);
      localStorage.setItem("devtype", this.devtype);
  },
  methods: {
    getLogin() {
        if(this.tenant == ''){
            return 1;
        }else{
            localStorage.setItem("tenant", this.tenant);
            this.$router.push({ path: "/login" });
        }
    }
  }
};
</script>

<style lang="less" scoped>
.home {
  width: 100vw;
  height: 100vh;
  background-image: url("../../src/assets/bg.jpg");
  background-size: 100% 100%;
}

.content {
  margin: 20vh 8vh;

  .title {
    display: inline-block;
    margin-bottom: 5vh;
  }
}

.van-cell {
  position: relative;
  display: -webkit-box;
  display: -webkit-flex;
  display: flex;
  box-sizing: border-box;
  width: 100%;
  padding: 10px 16px;
  overflow: hidden;
  color: #323233;
  font-size: 14.5px;
  line-height: 33px;
  background-color: #fff;
  border-radius: 5px;
}

.myBtn {
  width: 74vw;
  height: 7vh;
  border-radius: 15px;
  margin-top: 4vh;
}

.van-nav-bar {
  position: relative;
  z-index: 1;
  display: -webkit-box;
  display: -webkit-flex;
  display: flex;
  -webkit-box-align: center;
  -webkit-align-items: center;
  align-items: center;
  height: 46px;
  line-height: 1.5;
  text-align: center;
  background-color: #0396ff;
  -webkit-user-select: none;
  user-select: none;
}
</style>
