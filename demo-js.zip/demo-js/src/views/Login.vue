<template>
  <div>
    <span>正在登录中，请稍等...</span>
  </div>
</template>

<script>
import { IsTenantAvailable } from "@/api/login";
import { GetExternalAuthenticationProviders } from "@/api/login";
import { wechatCode } from "@/api/login";
import { wechatLogin } from "@/api/login";

export default {
  data() {
    return {
      tenant: localStorage.getItem("tenant"),
      code: "", 
      returnUrl: window.location.href
    };
  },
  created() {
    this.getTanentId();
    console.log(this.returnUrl)
  },
  methods: {
    // 获取租户ID
    getTanentId() {
         IsTenantAvailable(this.tenant).then(
            res => {
                localStorage.setItem("tenantId", res.result.tenantId);
                localStorage.setItem("loginProviderName", res.result.loginProviderName);
                this.getExternalAuthenticationProviders(res.result.tenantId);
            },
            error => {
              console.log("错误", error.message);
            }
          );
    },
    getExternalAuthenticationProviders(tenantId) {
       GetExternalAuthenticationProviders(tenantId).then(res => {
            this.startLogin(res.result[0].name, res.result[0].clientId);
        });
    },
    // 微信登陆
    startLogin(authProvider,clientId) {
      this.getCode();
      if (!this.code) {
        wechatCode(this.returnUrl, clientId);
        window.location.href = "https://hostapi.mzapi.com/api/TokenAuth/WechatLogin?clientId=" +clientId + "&returnUrl=" + this.returnUrl;
      } else {
        this.wechatLogin(authProvider);
      }
    },
    getCode() {
      if (this.$route.query.code != null) {
        this.code = this.$route.query.code;
      }
    },
    wechatLogin(authProvider) {
      wechatLogin(
        this.code,
        this.code,
        this.returnUrl,
        authProvider
      ).then(res=> {
        localStorage.setItem("token", res.result.accessToken);
        this.$router.push({ path: "/Device" });
      });
    },
  }
};
</script>
