import Vue from 'vue'
import Vuex from 'vuex'
import mutations from "./mutations";
//使vuex可以一直保存起来，解决刷新消失的问题
import createPersistedState from "vuex-persistedstate"

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    //记录数据
    
  },
  //由其他地方导入
  mutations,
  actions: {
  },
  modules: {
  },
  //使vuex刷新不重置的插件，可用性极高，可解决vue刷新vuex数据清空的问题
 //plugins: [createPersistedState()]
})
