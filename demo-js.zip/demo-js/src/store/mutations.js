//存放store中的数据改变方法

export default {
    
 
}