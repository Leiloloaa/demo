import Vue from 'vue'
import VueRouter, {
    RouteConfig
} from 'vue-router'
import Home from "../views/Home.vue";
Vue.use(VueRouter)
const routes = [{
        path: "/",
        name: "Home",
        component: Home
    },
    {
        path: "/home",
        name: "Home",
        component: Home
    },
    {
        path: "/login",
        name: "Login",
        component: () =>
            import ("../views/Login.vue")
    },
    {
        path: "/device",
        name: "Device",
        component: () =>
            import ("../views/Device.vue")
    }
]

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes
})

//下面是可通过控制不让跳转路由，如未登录等
// router.beforeEach((to, from, next) => {
//   if (to.path === '/login') {
//允许去登录
//     next(); 
//   } else {
//去其他路由需要验证是否有登录标识，如token
//     let token = localStorage.getItem('token');
//     if (token == null || token=='') {
//      next('/login')
//     // alert('请先登录')
//     } else {
//       next();
//     }
//   }
// })
export default router