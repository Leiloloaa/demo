import {
    request
} from "./request"

// 获取当前租户配置
export function IsTenantAvailable(tenancyName) {
    return request({
        method: "post",
        url: "/api/services/app/Account/IsTenantAvailable",
        data: {
            tenancyName,
        }
    })
}

// 扩展登录
export function GetExternalAuthenticationProviders(tenantId) {
    return request({
        method: "get",
        url: "/api/TokenAuth/GetExternalAuthenticationProviders?tenantId=" + tenantId,
    })
}

export function wechatCode(returnUrl, clientId) {
    return request({
        method: "get",
        url: "/api/TokenAuth/WechatLogin?clientId=" +
            clientId +
            "&returnUrl=" +
            returnUrl,
    })
}

export function wechatLogin(
    providerKey,
    providerAccessCode,
    returnUrl,
    authProvider
) {
    return request({
        method: "post",
        url: "/api/TokenAuth/ExternalAuthenticate",
        data: {
            authProvider,
            providerKey,
            providerAccessCode,
            returnUrl,
            singleSignIn: true,
        },
    })
}